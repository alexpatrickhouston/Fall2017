Assignment 3
Hey Pete, 
Got as much as I could done, testing is a bit iffy I can't manage to track down a bug that causes it to hang on my post
and I did include the stuff you did in lecture tonight (11/6) so im confused why the hanging
Ill try to test it further and get you a better working copy
